# Full Stack Todo Application

This repository contains a full-stack Todo application (backend + frontend) built with TypeScript, Node.js, Express, MongoDB, React, Vite and Tailwind.

Folders:
- `backend/`: Express + TypeScript backend
- `frontend/`: React + Vite frontend

See the original project spec for setup and run instructions.

Quick start:
1. Open the `todo-app` folder in VS Code.
2. For backend:
   - `cd backend`
   - `npm install`
   - create `.env` using `.env.example`
   - `npm run dev`
3. For frontend:
   - `cd frontend`
   - `npm install`
   - copy `.env.example` to `.env` (or set `VITE_API_URL`)
   - `npm run dev`

Enjoy!
