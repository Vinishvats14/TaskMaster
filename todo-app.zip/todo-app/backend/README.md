Backend of the Todo App

- `npm install`
- copy `.env.example` to `.env` and fill values
- `npm run dev` to start in development (nodemon + ts-node)
