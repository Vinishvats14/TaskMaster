Frontend of the Todo App

- `npm install`
- copy `.env.example` to `.env` and set `VITE_API_URL`
- `npm run dev` to start Vite dev server
