import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useNavigate } from 'react-router-dom';
import { todoAPI } from '../api/todo.api';
import { todoSchema, TodoInput } from '../schemas/todo.schema';
import { TodoItem } from '../components/TodoItem';
import { useAuthStore } from '../store/authStore';

export const TodosPage = () => {
  const [showForm, setShowForm] = useState(false);
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();

  const { data, isLoading } = useQuery({
    queryKey: ['todos'],
    queryFn: todoAPI.getTodos,
  });

  const { register, handleSubmit, reset, formState: { errors } } = useForm<TodoInput>({
    resolver: zodResolver(todoSchema),
  });

  const createMutation = useMutation({
    mutationFn: todoAPI.createTodo,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['todos'] });
      reset();
      setShowForm(false);
    },
  });

  const onSubmit = (data: TodoInput) => {
    createMutation.mutate(data);
  };

  const handleLogout = () => {
    logout();
    navigate('/signin');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-800">My Todos</h1>
          <div className="flex items-center gap-4">
            <span className="text-gray-600">Hello, {user?.name}!</span>
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto p-4 space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">
            Total: {data?.todos?.length || 0} todos
          </h2>
          <button
            onClick={() => setShowForm(!showForm)}
            className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
          >
            {showForm ? 'Cancel' : '+ New Todo'}
          </button>
        </div>

        {showForm && (
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-4">Create New Todo</h3>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                <input
                  {...register('title')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter todo title"
                />
                {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title.message}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description (optional)</label>
                <textarea
                  {...register('description')}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Enter todo description"
                  rows={3}
                />
                {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>}
              </div>

              {createMutation.isError && (
                <p className="text-red-500 text-sm">{(createMutation.error as any)?.response?.data?.message || 'Failed to create todo'}</p>
              )}

              <button
                type="submit"
                disabled={createMutation.isLoading}
                className="w-full py-2 px-4 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50"
              >
                {createMutation.isLoading ? 'Creating...' : 'Create Todo'}
              </button>
            </form>
          </div>
        )}

        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-gray-600">Loading todos...</p>
          </div>
        ) : data?.todos && data.todos.length > 0 ? (
          <div className="space-y-3">
            {data.todos.map((todo) => (
              <TodoItem key={todo._id} todo={todo} />
            ))}
          </div>
        ) : (
          <div className="text-center py-8 bg-white rounded-lg shadow-md">
            <p className="text-gray-600">No todos yet. Create your first one!</p>
          </div>
        )}
      </div>
    </div>
  );
};
